
import os
import json
from datetime import date
from dotenv import load_dotenv
from google import genai
from google.genai import types
from pydantic import BaseModel, Field, ValidationError


load_dotenv()

api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError("GEMINI_API_KEY is missing from .env")

client = genai.Client(api_key=api_key)



class Appointment(BaseModel):           # Define the appointment form
    patient_name: str | None = None
    phone_number: str | None = None
    doctor_name: str | None = None
    appointment_date: str | None = None
    appointment_time: str | None = None
    reason_for_visit: str | None = None

    missing_information: list[str] = Field(
        default_factory=list
    )


# Give the model clear instructions
SYSTEM_PROMPT = """
Extract appointment details from the patient's message.

Return only the fields in the provided schema.
Use null for information that is missing or unclear.
Never invent patient details, dates, times, or doctors.
Do not treat an unconfirmed appointment as booked.
Use YYYY-MM-DD for dates and 24-hour HH:MM for times.
Use the current date provided in the request to
interpret relative dates such as tomorrow.
Keep missing_information limited to required fields
that the clinic still needs to ask the patient for.

Required fields:
patient_name, phone_number, appointment_date,
appointment_time.

A doctor name and reason for visit are optional.
"""



def process_message(message: str) -> dict:          # Check the Whatsapp message
    today = date.today().isoformat()

    response = client.models.generate_content(
        model="gemini-3.8-flash",
        contents=(
            f"Today's date is {today}.\n"
            f"Extract the appointment details from this message:\n"
            f"{message}"
        ),
        config=types.GenerateContentConfig(
            system_instruction=SYSTEM_PROMPT,
            response_mime_type="application/json",
            response_schema=Appointment,
            max_output_tokens=1000,
            temperature=0,
        ),
    )

    # Check what the model actually returned
    print("\nDEBUG: Raw response =", repr(response.text))

    if not response.text:
        raise ValueError("The model returned an empty response.")

    # Validate JSON using Pydantic
    appointment = Appointment.model_validate_json(
        response.text
    )

    required_fields = [
        "patient_name",
        "phone_number",
        "appointment_date",
        "appointment_time",
    ]

    missing = []

    for field in required_fields:
        value = getattr(appointment, field)

        if value is None or not value.strip():
            missing.append(field)

    if appointment.appointment_date:
        try:
            date.fromisoformat(appointment.appointment_date)
        except ValueError:
            missing.append("valid_appointment_date")

    if appointment.appointment_time:
        from datetime import datetime

        try:
            datetime.strptime(
                appointment.appointment_time, "%H:%M"
            )
        except ValueError:
            missing.append("valid_appointment_time")

    appointment.missing_information = list(dict.fromkeys(missing))

    return appointment.model_dump()     # Return clean JSON


def main():
    print("=== Clinic Booking Form ===")

    message = input(
        "\nEnter the patient's WhatsApp message: "
    ).strip()

    if not message:
        print("Please enter a message.")
        return

    try:
        result = process_message(message)

        print("\n=== Appointment Form ===")
        print(json.dumps(result, indent=4))

        if result["missing_information"]:
            print("\nPlease ask the patient for:")
            for field in result["missing_information"]:
                print("-", field)
        else:
            print(
                "\nAll required fields are present. "
                "The appointment still needs confirmation "
                "and availability checking."
            )

    except ValidationError as error:
        print("The appointment data failed validation.")
        print(error)

    except Exception as error:
        print("Unable to process the message.")
        print(error)


if __name__ == "__main__":
    main()
